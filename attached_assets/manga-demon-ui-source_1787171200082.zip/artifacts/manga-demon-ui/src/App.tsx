import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Check,
  ChevronLeft,
  Globe2,
  Heart,
  ListFilter,
  MoreVertical,
  Search,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [activeTab, setActiveTab] = useState<'popular' | 'latest'>('latest');
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [siteInfoOpen, setSiteInfoOpen] = useState(false);
  const [overflowOpen, setOverflowOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [includeCompleted, setIncludeCompleted] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [feedbackVisible, setFeedbackVisible] = useState(false);

  const showFeedback = (message: string) => {
    setFeedback(message);
    setFeedbackVisible(true);
    window.setTimeout(() => setFeedbackVisible(false), 1800);
  };

  useEffect(() => {
    if (!searchOpen) {
      setSearchValue('');
    }
  }, [searchOpen]);

  const submitSearch = () => {
    const query = searchValue.trim();
    if (query) {
      showFeedback(`Searching for “${query}”`);
      setSearchOpen(false);
    } else {
      showFeedback('Type a title to search');
    }
  };

  return (
    <main className="manga-shell" data-testid="manga-demon-screen">
      <section className="browser-top" aria-label="Browser header">
        <div className="site-bar">
          <button
            type="button"
            className="back-button"
            aria-label="Go back"
            data-testid="button-browser-back"
            onClick={() => showFeedback('You are at the first page')}
          >
            <ChevronLeft size={54} strokeWidth={2.8} />
          </button>

          <div className="site-meta">
            <strong className="site-title" data-testid="text-site-title">Manga Demon (EN)</strong>
            <span className="site-address" data-testid="text-site-address">https://demonicscans.org</span>
          </div>

          <div className="site-actions">
            <button
              type="button"
              className="browser-action"
              aria-label={searchOpen ? 'Close search' : 'Search'}
              data-testid="button-browser-search"
              onClick={() => {
                setSearchOpen((open) => !open);
                setSiteInfoOpen(false);
                setOverflowOpen(false);
              }}
            >
              {searchOpen ? <X size={43} /> : <Search size={43} />}
            </button>
            <button
              type="button"
              className="browser-action"
              aria-label="Site information"
              data-testid="button-site-info"
              onClick={() => {
                setSiteInfoOpen((open) => !open);
                setOverflowOpen(false);
                setSearchOpen(false);
              }}
            >
              <Globe2 size={43} />
            </button>
            <button
              type="button"
              className="browser-action browser-action--menu"
              aria-label="More browser options"
              data-testid="button-browser-overflow"
              onClick={() => {
                setOverflowOpen((open) => !open);
                setSiteInfoOpen(false);
                setSearchOpen(false);
              }}
            >
              <MoreVertical size={39} />
            </button>
          </div>
        </div>

        {siteInfoOpen && (
          <aside className="browser-popover" data-testid="popover-site-info">
            <h2>Site information</h2>
            <p>Connection is secure. You are viewing the English catalog at demonicscans.org.</p>
          </aside>
        )}

        {overflowOpen && (
          <aside className="browser-popover overflow-menu" data-testid="menu-browser-overflow">
            <button type="button" data-testid="button-menu-reload" onClick={() => showFeedback('Page refreshed')}>Reload page</button>
            <button type="button" data-testid="button-menu-share" onClick={() => showFeedback('Link ready to share')}>Share site</button>
            <button type="button" data-testid="button-menu-bookmark" onClick={() => showFeedback('Bookmark saved')}>Add bookmark</button>
          </aside>
        )}

        <div className={`feedback${feedbackVisible ? ' is-visible' : ''}`} role="status" data-testid="status-feedback">
          {feedback}
        </div>
      </section>

      <section className="browser-content" aria-label="Manga Demon discovery controls">
        <nav className="reading-tabs" aria-label="Manga sections">
          <button
            type="button"
            className={`reading-tab${activeTab === 'popular' ? ' is-active' : ''}`}
            aria-pressed={activeTab === 'popular'}
            data-testid="button-tab-popular"
            onClick={() => {
              setActiveTab('popular');
              showFeedback('Popular manga selected');
            }}
          >
            <Heart fill={activeTab === 'popular' ? 'currentColor' : 'none'} />
            <span>Popular</span>
          </button>
          <button
            type="button"
            className={`reading-tab${activeTab === 'latest' ? ' is-active' : ''}`}
            aria-pressed={activeTab === 'latest'}
            data-testid="button-tab-latest"
            onClick={() => {
              setActiveTab('latest');
              showFeedback('Latest manga selected');
            }}
          >
            <Check />
            <span>Latest</span>
          </button>
          <button
            type="button"
            className={`reading-tab${filterOpen ? ' is-active' : ''}`}
            aria-pressed={filterOpen}
            data-testid="button-open-filter"
            onClick={() => {
              setFilterOpen((open) => !open);
              setSearchOpen(false);
            }}
          >
            <ListFilter />
            <span>Filter</span>
          </button>
        </nav>

        {searchOpen && (
          <form
            className="search-panel"
            data-testid="form-search"
            onSubmit={(event) => {
              event.preventDefault();
              submitSearch();
            }}
          >
            <Search size={19} aria-hidden="true" />
            <input
              autoFocus
              type="search"
              value={searchValue}
              placeholder="Search manga"
              aria-label="Search manga"
              data-testid="input-search-manga"
              onChange={(event) => setSearchValue(event.target.value)}
            />
            {searchValue && (
              <button
                type="button"
                className="search-clear"
                aria-label="Clear search"
                data-testid="button-clear-search"
                onClick={() => setSearchValue('')}
              >
                <X size={18} />
              </button>
            )}
            <button type="submit" className="search-submit" aria-label="Submit search" data-testid="button-submit-search">
              <Search size={18} />
            </button>
          </form>
        )}

        {filterOpen && (
          <aside className="filter-panel" data-testid="panel-filter">
            <div className="filter-heading">
              <span>Filter releases</span>
              <button
                type="button"
                className="filter-close"
                aria-label="Close filter"
                data-testid="button-close-filter"
                onClick={() => setFilterOpen(false)}
              >
                <X size={15} />
              </button>
            </div>
            <label className="filter-choice">
              <input
                type="checkbox"
                checked={includeCompleted}
                data-testid="input-include-completed"
                onChange={(event) => {
                  setIncludeCompleted(event.target.checked);
                  showFeedback(event.target.checked ? 'Completed series included' : 'Showing ongoing series');
                }}
              />
              <span>Include completed series</span>
            </label>
          </aside>
        )}

        <p className="reassurance" data-testid="text-active-view">
          {activeTab === 'latest' ? 'Latest releases' : 'Popular manga'}
          {includeCompleted ? ' · completed included' : ''}
        </p>
      </section>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;